=== A1D Monitoring and Management ===
Contributors:      Anthony DeLorenzo
Donate link:       https://a1d.co
Tags: 
Requires at least: 4.1.1
Tested up to:      4.1.1
Stable tag:        0.1.0
License:           GPLv2 or later
License URI:       http://www.gnu.org/licenses/gpl-2.0.html

A WordPress plugin for remote monitoring and management of other WordPress sites.

== Description ==

Easily add additional WordPress websites with this plugin, and monitor their status and uptime. 


== Installation ==

= Manual Installation =

1. Upload the entire `/monitoring` directory to the `/wp-content/plugins/` directory.
2. Activate A1D Monitoring and Management through the 'Plugins' menu in WordPress.

== Frequently Asked Questions ==


== Screenshots ==


== Changelog ==

= 0.1.0 =
* First release

== Upgrade Notice ==

= 0.1.0 =
First Release

== TODO ==
* Add better way to determine WP version (rss generator tags aren't updated unless posts are generated)
* Allow for remote updates
* enable email notifications
