/*! A1D Monitoring and Management - v0.1.0
 * https://a1d.co/monitoring
 * Copyright (c) 2015; * Licensed GPLv2+ */
( function( window, undefined ) {
	'use strict';


} )( this );
